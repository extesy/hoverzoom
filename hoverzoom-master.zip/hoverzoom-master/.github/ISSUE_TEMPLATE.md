**ATTENTION!** If you don't follow this template then your issue will be immediately closed.

## Description of the problem


## Url of the page where the problem occurs (not the image url)


## Steps to reproduce the problem (include image url here)
1.
2.
3.

## OS version, extension version (Chrome only, Firefox is not supported)

