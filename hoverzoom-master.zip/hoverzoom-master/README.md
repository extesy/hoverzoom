Hover Zoom+
===========

Google Chrome extension for zooming images on mouse hover.

> Please help with [localizing this extension](https://crowdin.com/project/hoverzoom) to the language you are familiar with!

This is a forked version of the popular extension by Romain Vallet which is now overrun with malware. All ads and malware are now removed and some bugs are fixed.

Licensed under MIT license.
